# Load required packages
library(dplyr)
library(readr)
library(stringr)
library(purrr)

# Function to process a single CSV file
process_file <- function(file_path) {
  cat("Processing:", file_path, "\n")
  
  # Read the CSV file
  df <- read_csv(file_path)
  
  # Extract condition, time point, and patient ID from sample_ID
  df <- df %>%
    mutate(
      condition = case_when(
        str_detect(sample_ID, "^LCLC") ~ "CYCLE",
        str_detect(sample_ID, "^LCSC") ~ "CYCLE-CS",
        TRUE ~ NA_character_
      ),
      tp = as.integer(str_sub(sample_ID, 5, 5)),
      Patient = str_sub(sample_ID, 6, 10)
    )
  
  # Day mapping based on the corrected information
  df <- df %>%
    mutate(
      Day = case_when(
        condition == "CYCLE" & tp == 1 ~ "Baseline",
        condition == "CYCLE" & tp == 2 ~ "Tag 3",
        condition == "CYCLE" & tp == 3 ~ "Tag 5",
        condition == "CYCLE" & tp == 4 ~ "Discharge",
        condition == "CYCLE-CS" & tp == 1 ~ "Baseline",
        condition == "CYCLE-CS" & tp == 2 ~ "Tag 1",
        condition == "CYCLE-CS" & tp == 3 ~ "Discharge",
        TRUE ~ paste("Unknown:", tp)  # Handle unexpected values
      )
    )
  
  # Create output file name
  output_file <- str_replace(file_path, "\\.csv$", "_processed.csv")
  
  # Write the processed data to a new CSV file
  write_csv(df, output_file)
  
  return(output_file)
}

# Process specific plate mapping files
plate_files <- list.files(pattern = "^plate_\\d+_mapping\\.csv$", full.names = TRUE)

# Process each plate file
processed_files <- map_chr(plate_files, process_file)

# Also process the all_plates_mapping.csv file if it exists
if (file.exists("all_plates_mapping.csv")) {
  all_plates_processed <- process_file("all_plates_mapping.csv")
  processed_files <- c(processed_files, all_plates_processed)
}

# Print summary
cat("\nProcessed", length(processed_files), "files:\n")
cat(paste(processed_files, collapse = "\n"), "\n")